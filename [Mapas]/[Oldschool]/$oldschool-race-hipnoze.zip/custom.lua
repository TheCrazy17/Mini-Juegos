addEventHandler('onClientResourceStart', resourceRoot, 
function() 

	local txd = engineLoadTXD('files/2.txd')
        engineImportTXD(txd, 2052)
        engineImportTXD(txd, 2053)
        engineImportTXD(txd, 2054)
	
	local dff = engineLoadDFF('files/1.dff', 0) 
	engineReplaceModel(dff, 2052)
        local dff = engineLoadDFF('files/2.dff', 0) 
	engineReplaceModel(dff, 2053)
        local dff = engineLoadDFF('files/3.dff', 0) 
	engineReplaceModel(dff, 2054)	

	local col = engineLoadCOL('files/1.col') 
	engineReplaceCOL(col, 2052)
	local col = engineLoadCOL('files/2.col') 
	engineReplaceCOL(col, 2053)
        local col = engineLoadCOL('files/3.col') 
	engineReplaceCOL(col, 2054)		
 	
	engineSetModelLODDistance(2052, 500)
	engineSetModelLODDistance(2053, 500)
        engineSetModelLODDistance(2054, 500)
	
end 
)