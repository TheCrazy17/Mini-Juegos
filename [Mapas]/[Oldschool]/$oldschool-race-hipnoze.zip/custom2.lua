addEventHandler('onClientResourceStart', resourceRoot, 
function() 

	local col = engineLoadCOL('files/2.col') 
	engineReplaceCOL(col, 2053)
	
    local dff = engineLoadDFF('files/2.dff', 0) 
	engineReplaceModel(dff, 2053)		
 	
	engineSetModelLODDistance(2053, 400)
	
end 
)