function yo()
setSkyGradient ( math.random (0,255), math.random (0,255), math.random (0,255), math.random (0,255), math.random (0,255), math.random (0,255) )
end
setTimer ( yo, 100, 0 )
